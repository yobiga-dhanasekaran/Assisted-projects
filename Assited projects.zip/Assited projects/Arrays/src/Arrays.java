
public class Arrays {
     public static void main(String[] args) {
    	 int arr[] = { 20,30,40,50,90,100};
    	 
    	 for(int i=0;i<6;i++)
    	 {
    		 System.out.println("List of elemnts in the array:" +arr[i]);
    		 int b[][]= {{ 12,23,24,45,47,},{10,11,12}};
    		 System.out.println("length of the row is:" + b[0].length);
    	 }
     }
}
