package constructors;

public class constructors {

	int id ;
	String name;
	
	constructors(int i ,String n){
		id =i;
		name=n;
		
	}
	void display() {
		System.out.println(id+" "+name);
		
	}
	public static void main(String[] args) {
		constructors obj1 = new constructors (01, "aishu");
		constructors obj2 = new constructors (02, "Balaji");
		//calling method to display the values of object 
		obj1.display();
		obj2.display();
	}
}
