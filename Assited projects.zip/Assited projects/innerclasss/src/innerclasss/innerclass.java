package innerclasss;

public class innerclass {
    private String msg= "Executing inner class";
    void display() {
    	class inner
    	{
    		void msg() {
    			System.out.println(msg);
    		}
    	}
    inner obj = new inner();
    obj.msg();
    }
 public static void main(String[] args) {
	 innerclass obj = new innerclass();
	 obj.display();
 }
}
