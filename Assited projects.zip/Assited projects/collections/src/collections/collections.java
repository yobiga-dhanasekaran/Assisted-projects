package collections;
import java.util.ArrayList;

public class collections {
    public static void main(String[] args)
    {
   	 ArrayList<Integer>arrlist = new ArrayList<Integer>();
   	 arrlist.add(3);
   	 arrlist.add(17);
   	 arrlist.add(29);
   	 arrlist.add(69);
   	 
   	 if(arrlist.contains(69)) {
   		 System.out.println("Found in the list");
   		 
   	 }
   	 else {
   		 System.out.println("not in the list ");
   	 }

    }
}